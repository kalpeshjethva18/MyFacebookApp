//
//  VideoCell.swift
//  facebookApp
//
//  Created by Harshul Shah on 30/01/17.
//  Copyright © 2017 Harshul Shah. All rights reserved.
//

import UIKit
import MediaPlayer

class VideoCell: UITableViewCell {

    var objBtnPlayPause : (() -> Void)? = nil
    @IBOutlet weak var btnPlayPause: UIButton!
    
    @IBOutlet weak var lblInternet: UILabel!
    
    @IBOutlet weak var actIndicator: UIActivityIndicatorView!
    var videoPlayer:AVPlayer! = nil
    var videoPlayerItem:AVPlayerItem! = nil
    var playerLayer:AVPlayerLayer! = nil
    
    var isPlay = Bool()
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBAction func btnPlayPauseAction(sender: UIButton)
    {
        if let btnPlayPauseAction = self.objBtnPlayPause
        {
            btnPlayPauseAction()
        }

    }
    func playVideo()
    {
        self.videoPlayer.actionAtItemEnd = .None
        self.videoPlayer.muted = false
        self.playerLayer = AVPlayerLayer(player: self.videoPlayer)
        self.playerLayer.frame = CGRectMake(0, 20, UIScreen.mainScreen().bounds.size.width , 280)
        self.playerLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
        self.layer.addSublayer(self.playerLayer)
        self.videoPlayer.play()
        
        
        //playerLayer.addObserver(self, forKeyPath: "readyForDisplay", options: [], context: nil)
      //  NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.pauseAllRunningPlayers), name: "pause", object: nil)
       /*
        
        self.videoPlayer.currentItem!.addObserver(self, forKeyPath: "status", options: NSKeyValueObservingOptions.New, context: nil)
        self.videoPlayer.currentItem!.addObserver(self, forKeyPath: "playbackBufferFull", options: NSKeyValueObservingOptions.New, context: nil)
        self.videoPlayer.currentItem!.addObserver(self, forKeyPath: "playbackBufferEmpty", options: NSKeyValueObservingOptions.New, context: nil)
        self.videoPlayer.currentItem!.addObserver(self, forKeyPath: "error", options: NSKeyValueObservingOptions.New, context: nil)
        
        */
      //  self.videoPlayerItem.addObserver(self, forKeyPath: "status", options: NSKeyValueObservingOptions.New, context: nil)

        self.videoPlayer.currentItem!.addObserver(self, forKeyPath: "status", options: NSKeyValueObservingOptions.New, context: nil)
       // self.videoPlayer.currentItem!.addObserver(self, forKeyPath: "rate", options: NSKeyValueObservingOptions.New, context: nil)
      //  self.videoPlayer.currentItem!.addObserver(self, forKeyPath: "duration", options: NSKeyValueObservingOptions.New, context: nil)
       // self.videoPlayer.currentItem!.addObserver(self, forKeyPath: "loadedTimeRanges", options: NSKeyValueObservingOptions.New, context: nil)



    }
    func StopVideo(mystring:String)
    {
        print("string from=== \(mystring)")
       self.videoPlayer.currentItem?.removeObserver(self, forKeyPath: "status", context: nil)
        self.playerLayer.removeFromSuperlayer()
        
        self.playerLayer.zPosition = 0 // or -1
       // self.videoPlayer.removeTimeObserver(self)

        
       // playerLayer.addObserver(self, forKeyPath: "readyForDisplay", options: [], context: nil)
        //  NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.pauseAllRunningPlayers), name: "pause", object: nil)
        //self.videoPlayer.currentItem?.removeObserver(self, forKeyPath: "rate", context: nil)
        //self.videoPlayer.currentItem?.removeObserver(self, forKeyPath: "duration", context: nil)
      //  self.videoPlayer.currentItem?.removeObserver(self, forKeyPath: "loadedTimeRanges", context: nil)
        //self.videoPlayer.currentItem?.removeObserver(self, forKeyPath: "playbackBufferFull", context: nil)
        //self.videoPlayer.currentItem?.removeObserver(self, forKeyPath: "playbackBufferEmpty", context: nil)
       // self.videoPlayer.currentItem?.removeObserver(self, forKeyPath: "error", context: nil)
    }
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
       
     /*    if (object as! AVPlayerItem).status == .ReadyToPlay {
         print("Ready to play")

            self.actIndicator.stopAnimating()
            self.actIndicator.hidden = true
            self.addSubview(actIndicator)

            
         }
         else if (object as! AVPlayerItem).status == .Failed {
         print("Failed to Ready")
            self.actIndicator.startAnimating()
            self.actIndicator.hidden = false
            self.addSubview(actIndicator)

         }
         else if (object as! AVPlayerItem).status == .Unknown {
         print("Not known")
            self.actIndicator.startAnimating()
            self.actIndicator.hidden = false
            self.addSubview(actIndicator)

         }
        */
         
         
         if self.videoPlayer.currentItem?.status == AVPlayerItemStatus.ReadyToPlay
         {
            print("playing")
            self.lblInternet.text = "your video is Playing"
            self.actIndicator.stopAnimating()
            self.actIndicator.hidden = true
            self.addSubview(actIndicator)
            

         }
         else if self.videoPlayer.currentItem?.status == AVPlayerItemStatus.Unknown
         {
            print("Buffering....")
            self.lblInternet.text = "your video is buffering"

            self.actIndicator.startAnimating()
            self.actIndicator.hidden = false
            self.addSubview(actIndicator)
         }
        else if self.videoPlayer.currentItem?.status == AVPlayerItemStatus.Failed
         {
            print("Please check your internet")
            self.lblInternet.text = "Please check your internet"
            self.actIndicator.startAnimating()
            self.actIndicator.hidden = false
            self.addSubview(actIndicator)

        }
        
        
      /*  if object is AVPlayerItem {
            
            //let durati:CMTime = object!.duration
          //  let currentTime = object!.currentTime()
            
          //  print("duration=== \(durati)")
          //  print("currentTime== \(currentTime)")
            
            
            switch keyPath! {
            case "playbackBufferEmpty":
                // Show loader
                
                self.actIndicator.startAnimating()
                self.actIndicator.hidden = false
                self.addSubview(actIndicator)

                print("Show loader1")
              //  lblStatus.text = "Buffering....Method"
                
            case "playbackLikelyToKeepUp":
                // Hide loader
                print("Hide loader")
                self.actIndicator.hidden = true
               // lblStatus.text = "Playing....Method"
                
            case "playbackBufferFull":
                // Hide loader
                print("Show loader2")
                self.actIndicator.hidden = false
               // self.actIndicator.removeFromSuperview()
                //lblStatus.text = "Playing....Method2"
                
            default:
                print("sdf")
              //  self.actIndicator.startAnimating()
               // self.actIndicator.hidden = false
                //self.addSubview(actIndicator)

            }
        }
        */
        
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
