//
//  ViewController.swift
//  facebookApp
//
//  Created by Harshul Shah on 30/01/17.
//  Copyright © 2017 Harshul Shah. All rights reserved.
//

import UIKit
import MediaPlayer

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIScrollViewDelegate
{
    @IBOutlet weak var tblFacebook: UITableView!
    @IBOutlet weak var scrollVideo: UIScrollView!
    
    var imgArray = NSMutableArray()
    var textArray = NSMutableArray()
    var videoArray = NSMutableArray()
    var isDragging = Bool()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        isDragging = false
        
        imgArray = NSMutableArray(objects: "k1","k2","k3","k4","k5","k6","k7","k1","k2","k3","k4","k5","k6","k7","k1","k2","k3","k4","k5","k6","k7","k1","k2","k3","k4","k5","k6","k7","k1","k2","k3","k4","k5","k6","k7")
        textArray = NSMutableArray(objects: "In iOS 8, Apple introduces a new feature for UITableView known as Self Sizing Cells. To me, this is seriously one of the most exciting features for the new SDK. Prior to iOS 8, if you want to display dynamic content in table view with variable height, you would need to calculate the row height manually.","Shimmer uses the -[CALayer mask] property to enable shimmering, similar to what's described in John Harper's 2009 WWDC talk (unfortunately no longer online). Shimmer uses CoreAnimation's timing features to smoothly transition  when starting and stopping the shimmer.","Now with iOS 8, Self Sizing Cell provides a solution for displaying dynamic content. In brief, here are what you need to do when using self sizing cells:","With just two lines of code, you instruct the table view to calculate the cell’s size matching its content and render it dynamically. This self sizing cell feature should save you tons of code and time. You’re gonna love it.","abc","Egf","With just two lines of code, you instruct the table view to calculate the cell’s size matching its content and render it dynamically. This self sizing cell feature should save you tons of code and time. You’re gonna love it.","In iOS 8, Apple introduces a new feature for UITableView known as Self Sizing Cells. To me, this is seriously one of the most exciting features for the new SDK. Prior to iOS 8, if you want to display dynamic content in table view with variable height, you would need to calculate the row height manually.","Shimmer uses the -[CALayer mask] property to enable shimmering, similar to what's described in John Harper's 2009 WWDC talk (unfortunately no longer online). Shimmer uses CoreAnimation's timing features to smoothly transition  when starting and stopping the shimmer.","Now with iOS 8, Self Sizing Cell provides a solution for displaying dynamic content. In brief, here are what you need to do when using self sizing cells:","With just two lines of code, you instruct the table view to calculate the cell’s size matching its content and render it dynamically. This self sizing cell feature should save you tons of code and time. You’re gonna love it.","abc","Egf","With just two lines of code, you instruct the table view to calculate the cell’s size matching its content and render it dynamically. This self sizing cell feature should save you tons of code and time. You’re gonna love it.","In iOS 8, Apple introduces a new feature for UITableView known as Self Sizing Cells. To me, this is seriously one of the most exciting features for the new SDK. Prior to iOS 8, if you want to display dynamic content in table view with variable height, you would need to calculate the row height manually.","Shimmer uses the -[CALayer mask] property to enable shimmering, similar to what's described in John Harper's 2009 WWDC talk (unfortunately no longer online). Shimmer uses CoreAnimation's timing features to smoothly transition  when starting and stopping the shimmer.","Now with iOS 8, Self Sizing Cell provides a solution for displaying dynamic content. In brief, here are what you need to do when using self sizing cells:","With just two lines of code, you instruct the table view to calculate the cell’s size matching its content and render it dynamically. This self sizing cell feature should save you tons of code and time. You’re gonna love it.","abc","Egf","With just two lines of code, you instruct the table view to calculate the cell’s size matching its content and render it dynamically. This self sizing cell feature should save you tons of code and time. You’re gonna love it.","In iOS 8, Apple introduces a new feature for UITableView known as Self Sizing Cells. To me, this is seriously one of the most exciting features for the new SDK. Prior to iOS 8, if you want to display dynamic content in table view with variable height, you would need to calculate the row height manually.","Shimmer uses the -[CALayer mask] property to enable shimmering, similar to what's described in John Harper's 2009 WWDC talk (unfortunately no longer online). Shimmer uses CoreAnimation's timing features to smoothly transition  when starting and stopping the shimmer.","Now with iOS 8, Self Sizing Cell provides a solution for displaying dynamic content. In brief, here are what you need to do when using self sizing cells:","With just two lines of code, you instruct the table view to calculate the cell’s size matching its content and render it dynamically. This self sizing cell feature should save you tons of code and time. You’re gonna love it.","abc","Egf","With just two lines of code, you instruct the table view to calculate the cell’s size matching its content and render it dynamically. This self sizing cell feature should save you tons of code and time. You’re gonna love it.","In iOS 8, Apple introduces a new feature for UITableView known as Self Sizing Cells. To me, this is seriously one of the most exciting features for the new SDK. Prior to iOS 8, if you want to display dynamic content in table view with variable height, you would need to calculate the row height manually.","Shimmer uses the -[CALayer mask] property to enable shimmering, similar to what's described in John Harper's 2009 WWDC talk (unfortunately no longer online). Shimmer uses CoreAnimation's timing features to smoothly transition  when starting and stopping the shimmer.","Now with iOS 8, Self Sizing Cell provides a solution for displaying dynamic content. In brief, here are what you need to do when using self sizing cells:","With just two lines of code, you instruct the table view to calculate the cell’s size matching its content and render it dynamically. This self sizing cell feature should save you tons of code and time. You’re gonna love it.","abc","Egf","With just two lines of code, you instruct the table view to calculate the cell’s size matching its content and render it dynamically. This self sizing cell feature should save you tons of code and time. You’re gonna love it.","56787654","sdfasefe","In iOS 8, Apple introduces a new feature for UITableView known as Self Sizing Cells. To me, this is seriously one of the most exciting features for the new SDK. Prior to iOS 8, if you want to display dynamic content in table view with variable height, you would need to calculate the row height manually")
        
        tblFacebook.rowHeight = UITableViewAutomaticDimension
        tblFacebook.estimatedRowHeight = 150
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footerView = UIView(frame: CGRectMake(0, 0, tableView.frame.size.width, 5))
        footerView.backgroundColor = UIColor.lightGrayColor()
        return footerView
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 27
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
       
        if indexPath.section % 3 == 0
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("cell1") as? LblCell
            cell?.lblText.text = textArray.objectAtIndex(indexPath.section) as? String
            cell?.lblText.numberOfLines = 0
            cell?.lblText.lineBreakMode = NSLineBreakMode.ByWordWrapping
            cell?.lblText.sizeToFit()
            return cell!
        }
        else if indexPath.section % 2 == 0
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("cell2") as? ImgCell
            cell?.imgView.image = UIImage(named: imgArray.objectAtIndex(indexPath.section) as! String)
            return cell!
        }
        else
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("cell3") as? VideoCell
            cell?.btnPlayPause.setTitle(String(indexPath.section), forState: UIControlState.Normal)
            cell?.backgroundColor = UIColor.redColor()
            print("video section is \(indexPath.section)")
            cell?.actIndicator.hidden = true
            cell?.lblInternet.text = ""
            cell?.lblInternet.textColor =  UIColor.whiteColor()
            
            cell?.objBtnPlayPause =
                 {
                    if cell?.isPlay == true
                    {
                        cell?.videoPlayer.pause()
                        cell?.isPlay = false
                    }
                    else
                    {
                        let videoURL = NSURL(string: "https://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4")
                        cell?.videoPlayer = AVPlayer(URL: videoURL!)
                        cell?.playVideo()
                        cell?.videoPlayer.play()
                        cell?.isPlay = true
                    }
            }
            return cell!
        }
    }
    func tableView(tableView: UITableView, didEndDisplayingCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        // stop video
       
        if let cell = cell as? VideoCell
        {
            if cell.isPlay == true
            {
                if ((cell.videoPlayer.rate != 0) && (cell.videoPlayer.error == nil))
                {
                    cell.isPlay = false
                    cell.lblInternet.text = ""
                    cell.playerLayer.zPosition = 0
                    cell.StopVideo("tableview end cell")
                    cell.videoPlayer = nil
                }
            }
        }
    }
    func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        // play video
    }
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        print("end dragging scroll")
        isDragging = false
    }
    func scrollViewDidEndDecelerating(scrollView: UIScrollView) {
        print("end declaring")
        isDragging = false
    }
    func scrollViewWillBeginDragging(scrollView: UIScrollView) {
        print("begign dragging")
        isDragging = true
    }
    func scrollViewDidScroll(scrollView: UIScrollView) {
        
        for cell: UITableViewCell in tblFacebook.visibleCells {
            if (cell is VideoCell) {
                let indexPath = tblFacebook.indexPathForCell(cell)!
                let cellRect = tblFacebook.rectForRowAtIndexPath(indexPath)
                let superview = tblFacebook.superview!
                let convertedRect = tblFacebook.convertRect(cellRect, toView: superview)
                let intersect = CGRectIntersection(tblFacebook.frame, convertedRect)
                let visibleHeight: CGFloat = CGRectGetHeight(intersect)
                
                if visibleHeight > 300.0 * 0.6 {
                    
                   // print("Visible video index path is    \(indexPath.section)")
                    if (cell as! VideoCell).isPlay == true
                    {
                       // print("cell is \((cell as! VideoCell).isPlay)")
                        
                    }
                    else
                    {
                        //print("cell is  \((cell as! VideoCell).isPlay)")
                        if isDragging == false
                        {
                            (cell as! VideoCell).isPlay = true
                            let videoURL = NSURL(string: "https://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4")
                            (cell as! VideoCell).videoPlayerItem = AVPlayerItem(URL: videoURL!)
                            (cell as! VideoCell).videoPlayer = AVPlayer(playerItem: (cell as! VideoCell).videoPlayerItem)
                            (cell as! VideoCell).playVideo()
                            (cell as! VideoCell).lblInternet.text = "your video is buffering"
                            (cell as! VideoCell).videoPlayer.play()
                        }
                    }
                }
                else {
                    
                   // let currentItem = (cell as! VideoCell).videoPlayer.currentItem
                    //let currentTime = CMTimeGetSeconds(currentItem!.currentTime())
                    
                    //print(" Capturing Time :\(currentTime) ")
                    
                    
                    if (cell as! VideoCell).isPlay == true //|| (cell as! VideoCell).isPlay == false
                    {
                        (cell as! VideoCell).isPlay = false
                        (cell as! VideoCell).lblInternet.text = ""
                        (cell as! VideoCell).playerLayer.zPosition = 0
                       // (cell as! VideoCell).videoPlayer.removeTimeObserver(self)
                        (cell as! VideoCell).StopVideo("scroll position \(indexPath.section)")
                        (cell as! VideoCell).videoPlayer = nil
                        //(cell as! VideoCell).videoPlayer.pause()
                    }
                    print("un visible video video index path is \(indexPath.section)")
                }
            }
        }
    }
    func playCell(cell: UITableViewCell)
    {
    }
   override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
/*
 Apple video player info:-
 1. https://developer.apple.com/av-foundation/
 */