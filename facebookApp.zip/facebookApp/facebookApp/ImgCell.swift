//
//  ImgCell.swift
//  facebookApp
//
//  Created by Harshul Shah on 30/01/17.
//  Copyright © 2017 Harshul Shah. All rights reserved.
//

import UIKit

class ImgCell: UITableViewCell {

    @IBOutlet weak var imgView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
